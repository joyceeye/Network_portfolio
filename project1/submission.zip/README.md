# change the readme.documentation and styling issue

## high-level approach: 
I design the program by letting the server run first. 
Letting the server listen. Then the client connects to the server.

## challenges faced:
the logic for the guess between client.py and server.py (how the guess and retry function works in each side)

###### high-level approach, any challenges you faced, the guessing strategy that your client implements, and an overview of how you tested your code.

## how to test the code
mainly by adding prints statement to check whether it works or not.
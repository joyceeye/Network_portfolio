** High-level approach
1） authoritative server for a specific domain
2) serve as a recursive resolver for a number of local clients
3) needs to handle non-responsive DNS servers by sending approp response to client requests
4) needs to check the integrity of every packet recv

** Lists of properties designed


** Test strategy
configs -> used to test dnsserver and send it queries
and also responds to clients

** Functionality:
interpret packets
manage dns cache
check for certain errors

** Things needs to pay attention to:
UDP port binds to 60053
if request with mutiple questions -> SERVFAIL
server never exits



response formatting:
dnslib includes DNSRecord.reply to build a skeleton reply from an incoming query, and the DNSRecord.pack method for formatting the DNS response

** libraries learned: 
RR.fromZone(): returns a generator of resourceRecord objects. Each objects has several attributes

## High-Level Approach
* connects to the remote server to change file status


## Challenges Faced
1. argument parsing for the copy and remove operations, since it has two path
2. data channel creation each data transmission operation and close it each time

## How to Test the Code:
1. Testing Communication:

* Added many print statements to verify that FTP server gets correct CODE for response

2. Argument Pass Issues(list):

* Debug with the 



# PASV and LIST:  creating a data channel, then implement the LIST command to test it.
    # multiple operation -> PASV/operation
    # PASV\r\n: Ask the FTP server to open a data channel.